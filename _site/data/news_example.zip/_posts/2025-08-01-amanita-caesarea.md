---
layout: post
title: "Amanita Caesarea: l’Ovulo Buono"
excerpt: "Scopriamo uno dei funghi più pregiati e apprezzati in cucina, l’Amanita Caesarea."
image: "/assets/images/amanita-caesarea.jpg"
---

L’**Amanita Caesarea**, conosciuta anche come *ovulo buono*, è un fungo molto apprezzato 
sia dai micologi che dagli appassionati di cucina. Si distingue per il cappello arancione, 
le lamelle gialle e il gambo anch’esso giallo.

In cucina è pregiato per il suo gusto delicato e viene consumato crudo in insalata, 
oppure grigliato con un filo d’olio d’oliva.
