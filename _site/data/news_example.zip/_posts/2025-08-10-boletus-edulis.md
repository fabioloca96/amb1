---
layout: post
title: "Boletus Edulis: Il Porcino"
excerpt: "Il re del bosco: il porcino, simbolo delle raccolte autunnali."
image: "/assets/images/boletus-edulis.jpg"
---

Il **Boletus Edulis**, noto come *porcino*, è uno dei funghi più ricercati e consumati in Italia.
Ha un cappello marrone, carnoso e un gambo robusto con una caratteristica reticolatura.

Il porcino è versatile in cucina: ottimo nei risotti, nelle paste fresche e come contorno trifolato.
