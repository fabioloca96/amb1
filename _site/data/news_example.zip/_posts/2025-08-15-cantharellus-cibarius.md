---
layout: post
title: "Cantharellus Cibarius: Il Finferlo"
excerpt: "Un fungo dal colore giallo acceso e dal profumo fruttato: il finferlo."
image: "/assets/images/cantharellus-cibarius.jpg"
---

Il **Cantharellus Cibarius**, comunemente chiamato *finferlo* o *gallinaccio*, 
si riconosce per il cappello a forma di imbuto e il colore giallo intenso.

Ha un sapore delicato e leggermente pepato. È perfetto saltato in padella o usato 
per condire tagliatelle fatte in casa.
