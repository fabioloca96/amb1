---
layout: post
title: "Ricette tradizionali con i funghi di montagna"
image: /assets/images/ricette-funghi.jpg
---

I funghi sono protagonisti di molte ricette tradizionali: dai risotti ai sughi, dalle tagliatelle ai contorni.

Un consiglio: esaltare il loro sapore con cotture semplici e pochi ingredienti genuini.
