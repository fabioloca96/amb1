---
layout: post
title: "I primi funghi autunnali nei boschi"
image: /assets/images/funghi-autunno.jpg
---

Con l’arrivo delle piogge di fine estate, i boschi iniziano a popolarsi dei primi funghi autunnali. Tra i più comuni troviamo i porcini, i finferli e le russole.

È importante raccogliere in modo responsabile, rispettando la natura e le normative locali.
