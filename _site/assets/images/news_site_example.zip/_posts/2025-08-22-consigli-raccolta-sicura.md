---
layout: post
title: "Consigli per una raccolta sicura dei funghi"
image: /assets/images/consigli-funghi.jpg
---

Raccogliere funghi è una passione che unisce natura e tradizione. Tuttavia, serve prudenza: mai consumare funghi non controllati da esperti micologi.

Portare sempre con sé un cestino di vimini, un coltellino e guanti adatti.
